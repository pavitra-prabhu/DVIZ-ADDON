# Import libraries
# Statistics libraries
library(matrixStats) # Includes weightedMedian
library(corrplot) # Includes corrplot function
library(robust) # Includes covRob function

# Data manipulation libraries
library(tibble) # includes rownames_to_column function
library(dplyr) # includes filter function
library(tidyr) # includes spread function
library(data.table) # includes shift function

# Visualization libraries
library(ggplot2) # Includes ggplot function
library(ggforce) # Includes geom_sina & geom_parallel_sets
library(ggridges) # Includes geom_
library(RColorBrewer) # For nice looking color palettes
library(cowplot) # Includes axis_canvas for generating A Canvas Onto Which One Can Draw Axis-Like Objects
library(forcats) # Includes fct_rev
library(treemapify) # Includes geom_treemap
library(ggrepel) # Includes geom_text_repel
library(GGally) # Includes ggparcoord
library(networkD3) # Includes sankeyNetwork function
library(ggalluvial) # Includes geom_alluvium

# Data API libraries
library(Quandl) # To import data from Quandl API
library(quantmod) # To import data using yahoo,google api

# Datetime Parsing functions
library(lubridate) # includes datetime parsing functions

# Resizing plot width and height from default 7
# https://www.rdocumentation.org/packages/repr/versions/0.7/topics/repr-options
options(repr.plot.width=10, repr.plot.height=4)
