# @title
# Color palettes for presentations
# @description
# A collection of colour palettes for data science projects for presentations
# main : basic color palette
# cool : color palette with cool colors
# hot : color palette with warmer colors
# div : color palette that puts equal emphasis on mid-range critical values and extremes at both ends of the data range.
# sseq : single sequence palette that are suited to ordered data that progress from low to high.
# mseq : multiple sequence palette that are suited to ordered data that progress from low to high.
# qual : color palette that creates the primary visual differences between classes.

# @examples
#' # Make an x-y plot using the qual palette
#' library(tidyverse)
#' df <- data.frame(x = rnorm(100, 0, 30),
#'           y = rnorm(100, 0, 30),
#'           cl = sample(letters[1:8], 100, replace=TRUE))
#' ggplot(df, aes(x, y, colour=cl, shape=cl)) +
#'   geom_point(size=4) + scale_color_pprabhu(palette="qual") +
#'   theme_bw() + theme(aspect.ratio=1)
#'
#' # Make a histogram using the McCrea Collins Street palette
#' ggplot(df, aes(x, fill=cl)) + geom_histogram() +
#'   scale_fill_pprabhu(palette="qual")
#'
# Base colors to be initialized in pprabhu_colors vector
pprabhu_colors <- c(
`red`        = "#e41a1c",
`green`      = "#4daf4a",
`lightgreen` = "#b2df8a",
`darkgreen`  = "#33a02c",
`blue`       = "#377eb8",
`lightblue`  = "#a6cee3",
`darkblue`   = "#1f78b4",
`lightorange`= "#fdbf6f",
`orange`     = "#ff7f00",
`yellow`     = "#ffff33",
`light grey` = "#cccccc",
`dark grey`  = "#666666",
`purple`     = "#984ea3",
`lightpurple`= "#cab2d6",
`darkpurple` = "#6a3d9a",
`brown`      = "#a65628",
`pink`       = "#f781bf",
`grey`       = "#999999",
`cream`      = "#ffff99",
`darkbrown`  = "#b15928",
`blues`      = c("#f7fbff","#deebf7","#c6dbef","#9ecae1","#6baed6","#4292c6","#08519c","#2171b5","#08306b"),
`YlGnBu`     = c("#ffffd9","#edf8b1","#c7e9b4","#7fcdbb","#41b6c4","#1d91c0","#225ea8","#253494","#081d58"),
`RdBu`       = c("#b2182b","#d6604d","#f4a582","#fddbc7","#f7f7f7","#d1e5f0","#92c5de","#4393c3","#2166ac"))



#' Function to extract colors from pprabhu_colors as hex codes
#' @param ... Character names of pprabhu_colors
pprabhu_cols <- function(...) {
cols <- c(...)

if (is.null(cols))
    return (pprabhu_colors)

pprabhu_colors[cols]
}

# Color palettes are prepared combining the base colors
pprabhu_palettes <-
list(
# Main color palette used if none specified
`main`  = pprabhu_cols("lightblue","darkblue", "lightgreen","darkgreen","pink","red","lightorange","orange","lightpurple","darkpurple","cream","darkbrown"),

`cool`  = pprabhu_cols("lightblue","darkblue", "lightgreen","darkgreen","pink"),

`hot`   = pprabhu_cols("yellow", "orange", "red"),

`div`   = pprabhu_cols("RdBu1","RdBu2","RdBu3","RdBu4","RdBu5","RdBu6","RdBu7","RdBu8","RdBu9"),

`sseq`  = pprabhu_cols("blues1","blues2","blues3","blues4","blues5","blues6","blues7","blues8","blues9"),

`mseq`  = pprabhu_cols("YlGnBu1","YlGnBu2","YlGnBu3","YlGnBu4","YlGnBu5","YlGnBu6","YlGnBu7","YlGnBu8","YlGnBu9"),

`qual`  = pprabhu_cols("red","blue","green","purple","orange","yellow","brown","pink","grey")
)

# Function to interpolate pprabhu_palettes color palettes
pprabhu_pal <- function(palette = "main", reverse = FALSE, ...) {
  pal <- pprabhu_palettes[[palette]]
  if (reverse){
    pal <- rev(pal)
  }
  # This function is useful for converting hand-designed `sequential' or `diverging' color schemes into continous color ramps
  return(colorRampPalette(pal, ...))
}

# Scales for ggplot2 : scale_fill function
scale_fill_pprabhu <- function(..., palette="main",
                               discrete = TRUE, reverse = TRUE) {

  input_pal <- pprabhu_pal(palette,reverse = reverse, ...)

  if (discrete) {
    discrete_scale("fill", paste0("pprabhu_",palette), palette=input_pal,...)
  }
  else {
    scale_fill_gradientn(colours = input_pal(256),...)
  }
}

# Scales for ggplot2 : scale_color function
scale_color_pprabhu <- function(..., palette="main",
                                discrete = TRUE, reverse = TRUE) {

  input_pal <- pprabhu_pal(palette,reverse = reverse, ...)

  if (discrete) {
    discrete_scale("colour", paste0("pprabhu_",palette), palette=input_pal,...)
  }
  else {
    scale_color_gradientn(colours = input_pal(256),...)
  }
}
